@extends('layouts.app')

@section('content')
<div class="container">
        @if (Session::has('message'))
            <div class="alert alert-success">{{ Session::get('message') }}</div>
        @endif
    <div class="row justify-content-center">
    <div class="row m-t-30">
    <div class="col-md-12">
    <button type="button" class="btn btn-primary" disabled>Total Orders Placed = {{$count}}</button>
        <!-- DATA TABLE-->
<div class="table-responsive m-b-40">
    <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>ID</th>
                <th> Name</th>
                <th> Detail</th>
                <th> Price</th>
                <th> Price</th>
                <th>Action</th>
              </tr>
        </thead>
        <tbody>
            @foreach ($orders as $order)
               <tr>
                <th>{{$order->id}}</th>
                @php
                   $product = App\Models\Product::where('id',$order->product_id)->first();
                @endphp 
                <th>{{$product->name}}</th>
                <th>{{$product->detail}}</th>
                <th>{{$product->price}}</th>
                <th>
                    @if($order->paid_status == '1')
                        Paid
                    @else
                        Unpaid
                    @endif
                </th>
                <th>
                @if($order->paid_status == '1')  
                        <button type="button" class="btn btn-success" disabled>Pay</button>
                @else
                    <a href="{{url('payorder/'.$order->id)}}">    
                        <button type="button" class="btn btn-secondary">Pay</button>
                    </a>  
                @endif      
                </th>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
        <!-- END DATA TABLE-->
    </div>
</div>
    </div>
</div>
@endsection