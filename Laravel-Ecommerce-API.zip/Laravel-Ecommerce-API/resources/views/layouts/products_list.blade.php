@extends('layouts.app')

@section('content')
<div class="container">
        @if (Session::has('message'))
            <div class="alert alert-success">{{ Session::get('message') }}</div>
        @elseif (Session::has('error'))
            <div class="alert alert-warning">{{ Session::get('error') }}</div>
        @endif
    <div class="row justify-content-center">
    <div class="row m-t-30">
    <div class="col-md-12">
        <!-- DATA TABLE-->
<div class="table-responsive m-b-40">
    <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>ID</th>
                <th> Name</th>
                <th> Detail</th>
                <th> Price</th>
                <th>Action</th>
              </tr>
        </thead>
        <tbody>
            @foreach ($products as $product)
               <tr>
                <th>{{$product->id}}</th>
                <th>{{$product->name}}</th>
                <th>{{$product->detail}}</th>
                <th>{{$product->price}}</th>
                <th>
                    <a href="{{url('placeorder/'.$product->id)}}">    
                        <button type="button" class="btn btn-primary">Place Order</button>
                    </a>        
                </th>
            </tr>
            @endforeach
        </tbody>
    </table>
</div>
        <!-- END DATA TABLE-->
    </div>
</div>
    </div>
</div>
@endsection