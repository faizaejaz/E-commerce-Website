<?php

namespace Database\Factories;

use App\Models\Product;
use App\Models\Order;
use App\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Order>
 */
class OrderFactory extends Factory
{
    protected $model = Order::class;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'user_id' => function() {
                return User::all()->random();
            },
            'product_id' => function() {
                return Product::all()->random();
            },
            'paid_status' => $this->faker->numberBetween(0,1)
        ];
    }
}

