<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Product::create([
            'name' => 'Laptop',
            'detail' => 'Lorem Ipsum es simplemente el texto',
            'price' => 200000,
        ]);

        Product::create([
            'name' => 'Mobile',
            'detail' => 'Lorem Ipsum es simplemente el texto',
            'price' => 100000,
        ]);

        Product::create([
            'name' => 'Tablet',
            'detail' => 'Lorem Ipsum es simplemente el texto',
            'price' => 90000,
        ]);

        Product::create([
            'name' => 'PC',
            'detail' => 'Lorem Ipsum es simplemente el texto',
            'price' => 300000,
        ]);

        Product::create([
            'name' => 'Speakers',
            'detail' => 'Lorem Ipsum es simplemente el texto',
            'price' => 15000,
        ]);

        Product::create([
            'name' => 'Mouse',
            'detail' => 'Lorem Ipsum es simplemente el texto',
            'price' => 2000,
        ]);

        Product::create([
            'name' => 'Trackpad',
            'detail' => 'Lorem Ipsum es simplemente el texto',
            'price' => 20000,
        ]);

        Product::create([
            'name' => 'Joystick',
            'detail' => 'Lorem Ipsum es simplemente el texto',
            'price' => 10000,
        ]);

        Product::create([
            'name' => 'Headphones',
            'detail' => 'Lorem Ipsum es simplemente el texto',
            'price' => 5000,
        ]);

        Product::create([
            'name' => 'Adopters',
            'detail' => 'Lorem Ipsum es simplemente el texto',
            'price' => 10000,
        ]);
    }
}
