# Laravel-Ecommerce-API
Simple and robust e-commerce API.

## Getting Started

for test These instructions will get you a copy of the project up and running on your local machine for development and testing purposes. See deployment for notes on how to deploy the project on a live system.

### Prerequisites

What things you need to install the software and how to install them

```
Laravel
PHP 8.1+
mysql

```

### Installing

A step by step series of examples that tell you how to get a development env running

Execute one by one

```
-> cp .env.example .env
-> composer install
-> php artisan key:generate 


-> php artisan migrate:fresh --seed
-> php artisan passport:install

-> php artisan serve
```

And repeat

```
```


## Running the tests

Postman

### create user token for create update and delete operation

-> (POST)localhost:8000/oauth/token

Headers
```
Accept : application/json
Content-Type : application/json
```

```

```

## Break down into end to end tests

Flow below instraction for test your API 

### Get all products
```
(GET) http://localhost:8000/api/products
```

### Get single products
```
(GET) http://localhost:8000/api/products/1
```

### Create products
```
(POST) http://localhost:8000/api/products

Headers
Accept : application/json
Content-Type : application/json
Authorization : "put your user secret"


```

### Update product 
```
same as create only change request post to put
```

### Delete product
```
(DELETE) http://localhost:8000/api/products/2
also need some headers as like as product create 
```

### Get all reviews in particular product
```
(GET) http://localhost:8000/api/products/1/reviews
```

### Create review
```
(POST) http://localhost:8000/api/products/1/reviews


```

### Delete review
```
(DELETE) http://localhost:8000/api/products/1/reviews/501
```
