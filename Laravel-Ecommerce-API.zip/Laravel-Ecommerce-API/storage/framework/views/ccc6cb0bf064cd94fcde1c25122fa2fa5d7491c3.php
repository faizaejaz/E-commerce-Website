<?php $__env->startSection('content'); ?>
<div class="container">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
        <?php endif; ?>
    <div class="row justify-content-center">
    <div class="row m-t-30">
    <div class="col-md-12">
    <button type="button" class="btn btn-primary" disabled>Total Orders Placed = <?php echo e($count); ?></button>
        <!-- DATA TABLE-->
<div class="table-responsive m-b-40">
    <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>ID</th>
                <th> Name</th>
                <th> Detail</th>
                <th> Price</th>
                <th> Price</th>
                <th>Action</th>
              </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                <th><?php echo e($order->id); ?></th>
                <?php
                   $product = App\Models\Product::where('id',$order->product_id)->first();
                ?> 
                <th><?php echo e($product->name); ?></th>
                <th><?php echo e($product->detail); ?></th>
                <th><?php echo e($product->price); ?></th>
                <th>
                    <?php if($order->paid_status == '1'): ?>
                        Paid
                    <?php else: ?>
                        Unpaid
                    <?php endif; ?>
                </th>
                <th>
                <?php if($order->paid_status == '1'): ?>  
                        <button type="button" class="btn btn-success" disabled>Pay</button>
                <?php else: ?>
                    <a href="<?php echo e(url('payorder/'.$order->id)); ?>">    
                        <button type="button" class="btn btn-secondary">Pay</button>
                    </a>  
                <?php endif; ?>      
                </th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
        <!-- END DATA TABLE-->
    </div>
</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cv-pc/Desktop/Laravel-Ecommerce-API-master/resources/views/layouts/orders_list.blade.php ENDPATH**/ ?>