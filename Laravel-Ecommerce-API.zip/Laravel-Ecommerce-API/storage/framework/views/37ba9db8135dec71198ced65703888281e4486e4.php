<?php $__env->startSection('content'); ?>
<div class="container">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
        <?php elseif(Session::has('error')): ?>
            <div class="alert alert-warning"><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>
    <div class="row justify-content-center">
    <div class="row m-t-30">
    <div class="col-md-12">
        <!-- DATA TABLE-->
<div class="table-responsive m-b-40">
    <table class="table table-borderless table-data3">
        <thead>
            <tr>
                <th>ID</th>
                <th> Name</th>
                <th> Detail</th>
                <th> Price</th>
                <th>Action</th>
              </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                <th><?php echo e($product->id); ?></th>
                <th><?php echo e($product->name); ?></th>
                <th><?php echo e($product->detail); ?></th>
                <th><?php echo e($product->price); ?></th>
                <th>
                    <a href="<?php echo e(url('placeorder/'.$product->id)); ?>">    
                        <button type="button" class="btn btn-primary">Place Order</button>
                    </a>        
                </th>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
        <!-- END DATA TABLE-->
    </div>
</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/cv-pc/Desktop/Laravel-Ecommerce-API-master/resources/views/layouts/products_list.blade.php ENDPATH**/ ?>