<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\User;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\OrderRequest;
use App\Exceptions\ProductNotBelongsToUser;
use Symfony\Component\HttpFoundation\Response;
use App\Http\Resources\Order\OrderResource;
use Session;
use View;
use Illuminate\Support\Facades\Redirect;
// use App\Http\Resources\Order\OrderCollection;

class OrderController extends Controller
{

    public function __construct(){
        $this->middleware('auth:api')->except('index','show', 'placeOrder', 'showAll', 'payOrder');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $user = Auth::id();
        // dd($user);
        $orders = Order::paginate(9);
        return $orders;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function showAll()
    {
        $user = Auth::id();
        $orders = Order::where('user_id', $user)->paginate(9);
        if($orders->count()<5){
            $count = 5;
        }
        elseif($orders->count()<17){
            $count = 17;
        }
        elseif($orders->count()<34){
            $count = 34;
        }
        elseif($orders->count()<50){
            $count = 50;
        }
        else{
            $count = $orders->count;
        }
        return View::make(
            'layouts.orders_list', compact('orders', 'count')
        );
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(OrderRequest $request)
    {
        $user = Auth::id();
        $status = 1;
        $users_orders = Order::where('user_id', $user)->get();
        foreach($users_orders as $user_order){
            if($user_order->paid_status == '0'){
                $status = 0;
                break; 
            }
            else{
                $status = 1;
            }
        }
        $order = new Order;
        if ($status == '1') {
            $order->user_id = Auth::id();
            $order->product_id = $request->product_id;
            $order->paid_status = $request->paid_status;
            $order->save();
            return response([
            'Order has been placed'
        ], 201);
        }
        else{
            return response('You have not unpaid orders', 200);
        }
    }

    public function placeOrder($id)
    {
        $user = Auth::id();
        $status = 0;
        $users_orders = Order::where('user_id', $user)->get();
        if($users_orders->isEmpty()){
            $order = new Order;
            $order->user_id = Auth::id();
                $order->product_id = $id;
                $order->paid_status = 0;
                $order->save();
                Session::flash('message', 'Order has been placed.');
                return Redirect::back();
        }
        else{
            foreach($users_orders as $user_order){
                if($user_order->paid_status == '0'){
                    $status = 0;
                    break; 
                }
                else{
                    $status = 1;
                }
            }
            $order = new Order;
            if ($status == '1') {
                $order->user_id = Auth::id();
                $order->product_id = $id;
                $order->paid_status = 0;
                $order->save();
                Session::flash('message', 'Order has been placed.');
                return Redirect::back();
            }
            else{
                Session::flash('error', 'You have unpaid orders.');
                return Redirect::back();
            }
            
        }
        
    }

    public function payOrder($id)
    {
        $user = Auth::id();
        $update_order = Order::where('id', $id)
        ->update([
            'paid_status'     => 1
        ]);
        Session::flash('message', 'Order has been paid.');
        return Redirect::back();
        
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function show(Order $order)
    {
        return new OrderResource($order);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function edit(Order $order)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Order $order)
    {
        $this->OrderUserCheck($order);
        // $request['paid_status'] = $request->paid_status;
        // unset($request['paid_status']);
        $order->update($request->all());
        return response([
            'data' => new OrderResource($order)
        ],Response::HTTP_OK);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Models\Order  $order
     * @return \Illuminate\Http\Response
     */
    public function destroy(Order $order)
    {
        $this->OrderUserCheck($order);
        $order->delete();
        return response(null,204);
    }

    public function OrderUserCheck($order){
        if (Auth::id() !== $order->user_id) {
           throw new OrderNotBelongsToUser;
           
        }
    }
}
