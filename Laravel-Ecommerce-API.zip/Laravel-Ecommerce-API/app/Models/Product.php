<?php

namespace App\Models;

use App\User;
use App\Models\Order;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = ['name','detail','price'];


    // public function user(){
    //     return $this->belongsTo(User::class);
    // }
    public function orders(){
        return $this->hasMany(Order::class);
    }
}
